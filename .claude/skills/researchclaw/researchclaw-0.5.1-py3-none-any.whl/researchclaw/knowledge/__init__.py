"""Knowledge management — base, adapters."""
